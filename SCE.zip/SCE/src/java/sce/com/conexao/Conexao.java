package sce.com.conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/estoque", "root", "");
        } catch (ClassNotFoundException | SQLException e) {
            throw new SQLException("Erro de conexão com o banco de dados", e);
        }
    }
}
