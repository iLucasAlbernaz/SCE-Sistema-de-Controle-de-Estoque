package sce.com.bean;

import sce.com.conexao.Conexao;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@ManagedBean
@ViewScoped
public class ProdutoBean implements Serializable {

    private Produto produto = new Produto();
    private List<Produto> produtos = new ArrayList<>();
    private String filtroNome;
    private String filtroCategoria;
    private BigDecimal filtroPrecoMin;
    private BigDecimal filtroPrecoMax;
    private Integer filtroQuantidadeMin;
    private Integer filtroQuantidadeMax;
    private int produtoId;

    // Construtor
    public ProdutoBean() {
        produto = new Produto();
        produtos = new ArrayList<>();
    }

    @PostConstruct
    public void init() {
        carregarProdutos(); // Carrega a lista de produtos ao iniciar
        carregarProdutoParaEdicaoOuExclusao();
    }

    // Método para carregar a lista de produtos com filtros
    public void carregarProdutos() {
        produtos.clear();
        try (Connection conn = Conexao.getConnection()) {
            StringBuilder sql = new StringBuilder("SELECT * FROM produto WHERE 1=1");

            if (filtroNome != null && !filtroNome.isEmpty()) {
                sql.append(" AND nome LIKE ?");
            }
            if (filtroCategoria != null && !filtroCategoria.isEmpty()) {
                sql.append(" AND categoria LIKE ?");
            }
            if (filtroPrecoMin != null) {
                sql.append(" AND preco >= ?");
            }
            if (filtroPrecoMax != null) {
                sql.append(" AND preco <= ?");
            }
            if (filtroQuantidadeMin != null) {
                sql.append(" AND quantidade >= ?");
            }
            if (filtroQuantidadeMax != null) {
                sql.append(" AND quantidade <= ?");
            }

            try (PreparedStatement ps = conn.prepareStatement(sql.toString())) {
                int index = 1;
                if (filtroNome != null && !filtroNome.isEmpty()) {
                    ps.setString(index++, "%" + filtroNome + "%");
                }
                if (filtroCategoria != null && !filtroCategoria.isEmpty()) {
                    ps.setString(index++, "%" + filtroCategoria + "%");
                }
                if (filtroPrecoMin != null) {
                    ps.setBigDecimal(index++, filtroPrecoMin);
                }
                if (filtroPrecoMax != null) {
                    ps.setBigDecimal(index++, filtroPrecoMax);
                }
                if (filtroQuantidadeMin != null) {
                    ps.setInt(index++, filtroQuantidadeMin);
                }
                if (filtroQuantidadeMax != null) {
                    ps.setInt(index++, filtroQuantidadeMax);
                }

                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        Produto p = new Produto();
                        p.setId(rs.getInt("id"));
                        p.setNome(rs.getString("nome"));
                        p.setDescricao(rs.getString("descricao"));
                        p.setCategoria(rs.getString("categoria"));
                        p.setPreco(rs.getBigDecimal("preco"));
                        p.setQuantidade(rs.getInt("quantidade"));
                        produtos.add(p);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    

    // Método para carregar o produto selecionado para edição ou exclusão
    private void carregarProdutoParaEdicaoOuExclusao() {
        String produtoIdParam = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("produtoId");
        if (produtoIdParam != null) {
            this.produtoId = Integer.parseInt(produtoIdParam);
            carregarProdutoPorId(produtoId);
        }
    }

    // Método para carregar um produto pelo ID
    public void carregarProdutoPorId(int produtoId) {
        try (Connection conn = Conexao.getConnection()) {
            String sql = "SELECT * FROM produto WHERE id = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, produtoId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        produto.setId(rs.getInt("id"));
                        produto.setNome(rs.getString("nome"));
                        produto.setDescricao(rs.getString("descricao"));
                        produto.setCategoria(rs.getString("categoria"));
                        produto.setPreco(rs.getBigDecimal("preco"));
                        produto.setQuantidade(rs.getInt("quantidade"));
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    // Método para excluir um produto
public void excluirProduto() {
    try (Connection conn = Conexao.getConnection()) {
        String sql = "DELETE FROM produto WHERE id = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, produto.getId()); // Define o ID do produto a ser excluído

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_INFO, "Produto excluído com sucesso!", null));
                produto = new Produto(); // Limpar o objeto após a exclusão
                carregarProdutos(); // Recarregar a lista de produtos após a exclusão
            } else {
                FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_WARN, "Produto não encontrado para exclusão.", null));
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        FacesContext.getCurrentInstance().addMessage(null,
            new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro ao excluir o produto.", null));
    }
}


    // Método para salvar o produto (somente inserir novo produto)
public void salvarProduto() {
    try (Connection conn = Conexao.getConnection()) {
        String sql = "INSERT INTO produto (nome, descricao, preco, quantidade, categoria) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, produto.getNome());
            ps.setString(2, produto.getDescricao());
            ps.setBigDecimal(3, produto.getPreco());
            ps.setInt(4, produto.getQuantidade());
            ps.setString(5, produto.getCategoria());

            ps.executeUpdate();
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Produto salvo com sucesso!", null));
            produto = new Produto(); // Limpar o objeto após salvar
            carregarProdutos(); // Recarregar a lista de produtos após a inserção
        }
    } catch (SQLException e) {
        e.printStackTrace();
        FacesContext.getCurrentInstance().addMessage(null,
            new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro ao salvar o produto.", null));
    }
}


    // Getters e Setters
    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public List<Produto> getProdutos() {
        return produtos;
    }

    public String getFiltroNome() {
        return filtroNome;
    }

    public void setFiltroNome(String filtroNome) {
        this.filtroNome = filtroNome;
    }

    public String getFiltroCategoria() {
        return filtroCategoria;
    }

    public void setFiltroCategoria(String filtroCategoria) {
        this.filtroCategoria = filtroCategoria;
    }

    public BigDecimal getFiltroPrecoMin() {
        return filtroPrecoMin;
    }

    public void setFiltroPrecoMin(BigDecimal filtroPrecoMin) {
        this.filtroPrecoMin = filtroPrecoMin;
    }

    public BigDecimal getFiltroPrecoMax() {
        return filtroPrecoMax;
    }

    public void setFiltroPrecoMax(BigDecimal filtroPrecoMax) {
        this.filtroPrecoMax = filtroPrecoMax;
    }

    public Integer getFiltroQuantidadeMin() {
        return filtroQuantidadeMin;
    }

    public void setFiltroQuantidadeMin(Integer filtroQuantidadeMin) {
        this.filtroQuantidadeMin = filtroQuantidadeMin;
    }

    public Integer getFiltroQuantidadeMax() {
        return filtroQuantidadeMax;
    }

    public void setFiltroQuantidadeMax(Integer filtroQuantidadeMax) {
        this.filtroQuantidadeMax = filtroQuantidadeMax;
    }

    public int getProdutoId() {
        return produtoId;
    }

    public void setProdutoId(int produtoId) {
        this.produtoId = produtoId;
    }
}
