package sce.com.bean;

import sce.com.conexao.Conexao;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@ManagedBean
@ViewScoped
public class LoginBean implements Serializable {

    private String email;
    private String senha;

    // Método para realizar o login
    public String login() {
        if (validarLogin()) {
            // Redireciona para a página inicial em caso de sucesso
            return "index.xhtml?faces-redirect=true";
        } else {
            // Exibe mensagem de erro em caso de falha
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Email ou senha inválidos.", null));
            return null; // Permanece na página atual
        }
    }

    // Validação do login com consulta ao banco de dados
    private boolean validarLogin() {
        String sql = "SELECT COUNT(*) FROM usuario WHERE email = ? AND senha = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);
            ps.setString(2, senha);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0; // Retorna verdadeiro se encontrar um usuário correspondente
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Log de erro para depuração
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro ao conectar ao banco de dados.", null));
        }
        return false;
    }

    // Getters e Setters
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}
