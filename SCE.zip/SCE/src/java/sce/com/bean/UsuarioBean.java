package sce.com.bean;

import sce.com.conexao.Conexao;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.io.Serializable;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@ManagedBean
@ViewScoped
public class UsuarioBean implements Serializable {

    private Usuario usuario = new Usuario();
    private List<Usuario> usuarios = new ArrayList<>();

    // Método para cadastrar um novo usuário
    public void cadastrarUsuario() {
        // Verificando se todos os campos obrigatórios foram preenchidos
        if (usuario.getNome() == null || usuario.getNome().isEmpty()) {
            FacesContext.getCurrentInstance().addMessage(null, 
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "O campo Nome é obrigatório.", null));
            return;
        }

        if (usuario.getEmail() == null || usuario.getEmail().isEmpty()) {
            FacesContext.getCurrentInstance().addMessage(null, 
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "O campo E-mail é obrigatório.", null));
            return;
        }

        if (usuario.getSenha() == null || usuario.getSenha().isEmpty()) {
            FacesContext.getCurrentInstance().addMessage(null, 
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "O campo Senha é obrigatório.", null));
            return;
        }

        // Verificando se o nome já existe no banco de dados
        if (emailJaExiste(usuario.getEmail())) {
            FacesContext.getCurrentInstance().addMessage(null, 
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro ao cadastrar usuário", 
                                 "O e-mail informado já está em uso. Por favor, digite outro e-mail."));
            return;
        }

        String sql = "INSERT INTO usuario (nome, email, senha) VALUES (?, ?, ?)";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            // Definindo os parâmetros para o SQL
            ps.setString(1, usuario.getNome());
            ps.setString(2, usuario.getEmail());
            ps.setString(3, usuario.getSenha()); // Aqui a senha será armazenada como texto simples. Considere usar um hash para segurança.

            // Executa a inserção
            ps.executeUpdate();

            // Limpa o objeto usuário após a inserção
            usuario = new Usuario();

            // Exibe mensagem de sucesso
            FacesContext.getCurrentInstance().addMessage(null, 
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Cadastro realizado com sucesso!", 
                                 "O usuário foi cadastrado com sucesso na base de dados."));

            // Recarrega a lista de usuários
            carregarUsuarios();
            
        } catch (SQLException e) {
            e.printStackTrace(); // Trate o erro de forma apropriada

            // Exibe mensagem de erro caso haja algum problema
            FacesContext.getCurrentInstance().addMessage(null, 
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro ao cadastrar usuário.", 
                                 "Verifique os dados e tente novamente. Caso o erro persista, entre em contato com o suporte."));
        }
    }

    // Método para verificar se o nome do usuário já existe no banco de dados
    private boolean emailJaExiste(String email) {
        String sql = "SELECT COUNT(*) FROM usuario WHERE email = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0; // Se o contador for maior que 0, o nome já existe
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public void excluirUsuario(Usuario usuarioSelecionado) {
    String sql = "DELETE FROM usuario WHERE id = ?";

    try (Connection conn = Conexao.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setInt(1, usuarioSelecionado.getId());
        ps.executeUpdate();

        FacesContext.getCurrentInstance().addMessage(null, 
            new FacesMessage(FacesMessage.SEVERITY_INFO, "Usuário excluído com sucesso.", null));

        carregarUsuarios(); // Recarregar a lista de usuários para refletir a exclusão

    } catch (SQLException e) {
        e.printStackTrace();
        FacesContext.getCurrentInstance().addMessage(null, 
            new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro ao excluir o usuário.", "Tente novamente."));
    }
}
    // Método para selecionar um usuário para edição
    public void editarUsuario(Usuario usuarioSelecionado) {
        this.usuario = usuarioSelecionado; // Preenche o objeto usuario para edição
    }
    
    public void salvarEdicao() {
    String sql = "UPDATE usuario SET nome = ?, email = ?, senha = ? WHERE id = ?";

    try (Connection conn = Conexao.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setString(1, usuario.getNome());
        ps.setString(2, usuario.getEmail());
        ps.setString(3, usuario.getSenha());
        ps.setInt(4, usuario.getId());

        ps.executeUpdate();

        FacesContext.getCurrentInstance().addMessage(null, 
            new FacesMessage(FacesMessage.SEVERITY_INFO, "Usuário editado com sucesso.", null));

        carregarUsuarios(); // Recarrega a lista após salvar a edição
        usuario = new Usuario(); // Reseta o formulário

    } catch (SQLException e) {
        e.printStackTrace();
        FacesContext.getCurrentInstance().addMessage(null, 
            new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro ao editar o usuário.", "Tente novamente."));
    }
}

    // Método para carregar todos os usuários do banco
    public void carregarUsuarios() {
        usuarios.clear();  // Limpa a lista antes de carregar novamente

        String sql = "SELECT * FROM usuario";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Usuario u = new Usuario();
                u.setId(rs.getInt("id"));
                u.setNome(rs.getString("nome"));
                u.setEmail(rs.getString("email"));
                u.setSenha(rs.getString("senha"));
                usuarios.add(u);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Getters e Setters
    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
}
